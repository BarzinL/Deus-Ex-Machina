# Deus Ex Machina

**Universal framework for accelerating scientific discovery through hierarchical lookup table (LUT) composition.**

[![License: Dual (AGPLv3/Commercial)](https://img.shields.io/badge/License-Dual%20(AGPLv3%2FCommercial)-blue.svg)](#license)
[![Python 3.13+](https://img.shields.io/badge/python-3.13+-blue.svg)](https://www.python.org/downloads/)

---

## Vision

Reality has natural hierarchical structure:
- **Physics**: particles → atoms → molecules → materials
- **Biology**: amino acids → proteins → cells → tissues
- **Engineering**: components → circuits → systems

**Core Hypothesis**: If we:
1. Identify hierarchical levels in a domain.
2. Cache primitives at each level as LUTs.
3. Define composition rules between levels.
4. Search at appropriate abstraction.

Then: **Orders of magnitude speedup** vs. brute force computation.

### The Architectural Pattern

This project implements a software architecture designed to transform $O(N^k)$ search problems into $O(N \times k)$ lookup problems. By identifying "compositional boundaries"—points where a system crystallizes into a stable unit—we can cache complex structures as simple primitives.

Key component: **The Crystallization Detector**. An algorithm that compares naive additive predictions against ground-truth data (experiment or simulation) to automatically identify stable abstractions (like aromatic rings) without hardcoded rules.

---

## Architecture

### 3-Layer Hierarchy

```

Layer -1: Standard Model (Fundamental Physics)
├─ Elementary particles, forces, conservation laws
├─ QED corrections, nuclear shell model
└─ Composition rules → Level 0

Level 0: Periodic Table (Elements)
├─ 118 observed + 55 theoretical elements (Z=1-173)
├─ Electron configurations, atomic properties
├─ Stability classification (OBSERVED | PREDICTED | SUPERCRITICAL | IMPOSSIBLE)
└─ Composition rules → Level 1

Level 1: Chemical Bonds & Functional Groups
├─ Bond types (covalent, ionic, metallic, hydrogen)
├─ Functional groups (\~500-1000 patterns)
├─ Small molecules (\<10 atoms)
└─ Composition rules → Level 2

Level 2: Molecular Compounds
├─ Known compounds (\~200M in databases)
├─ Properties computed via composition from Level 1
├─ Reaction pathways
└─ Composition rules → Level 3+

````

### Validation Status

The framework has been validated on a benchmark set of chemical structures:
- **Rediscovery of Aromaticity:** Automatically flagged Benzene as a "Must Cache" primitive due to its high stability violation (+148 kJ/mol).
- **Control Cases:** Correctly identified Ethylene as an additive structure (~0 violation), confirming the system does not overfit.
- **Diminishing Returns:** Detected non-linear scaling in fused ring systems (Naphthalene).

---

## Installation

```bash
# Clone repository
git clone [https://github.com/BarzinL/Deus-Ex-Machina.git](https://github.com/BarzinL/Deus-Ex-Machina.git)
cd Deus-Ex-Machina

# Create virtual environment with uv
uv venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate

# Install dependencies
uv pip install -e .
````

-----

## Usage

### Run the Crystallization Detector

```python
from src.crystallization.detector import CrystallizationDetector

# Initialize detector
detector = CrystallizationDetector(violation_threshold=0.05)

# Measure violation for a structure
violation = detector.measure_additivity_violation(
    structure=benzene,
    naive_fn=sum_bond_energies,
    actual_value=5470 # kJ/mol (experimental)
)

if violation.is_significant():
    print("Compositional boundary detected! Cache this unit.")
```

-----

## License

**Dual License: AGPLv3 or Commercial**

This software is available under a dual-licensing model:

### Open Source License (AGPLv3)

Free for non-commercial, open-source, and research use. This software is very copyleft and very free. Derivative works must also be open-sourced under AGPLv3.

### Commercial License

Required for commercial use, proprietary applications, or closed-source modifications.

**Commercial licensing contact:**

  - Email: barzin@duck.com
  - Web: https://sanctus.ca

See [LICENSE](https://www.google.com/search?q=LICENSE) for full details.

-----

## Contact

**Project**: Deus Ex Machina
**Author**: Barzin Lotfabadi
**Repository**: https://github.com/BarzinL/Deus-Ex-Machina

-----

**"From the machine, scientific discovery."**
