"""
Level 1: Chemical Bonds & Functional Groups

This level implements composition rules from Level 0 (Elements) → Level 1 (Bonds).

Modules:
- bonding: Bond formation prediction between elements
"""
